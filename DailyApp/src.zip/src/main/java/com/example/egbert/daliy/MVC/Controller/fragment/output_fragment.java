package com.example.egbert.daliy.MVC.Controller.fragment;

/**
 * Created by ScottPong on 2018/11/18.
 */

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import com.example.egbert.daliy.MVC.AccountActivity;
import com.example.egbert.daliy.R;


public class output_fragment extends Fragment implements View.OnClickListener {
    private TextView type_text;
    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Button button5;
    private Button button6;
    private Button button7;
    private Button button8;
    private Button button9;
    private Button button10;
    private Animation icon_animation;
    private  Button icon;
    private int[] IconsBG = new int[]{R.drawable.item_icon1,R.drawable.item_icon2,R.drawable.item_icon3,
            R.drawable.item_icon4,R.drawable.item_icon5,R.drawable.item_icon6,R.drawable.item_icon7,R.drawable.item_icon8,R.drawable.item_icon9,
            R.drawable.item_icon10};
    private int[] Icons = new int[]{R.drawable.food,R.drawable.trans,R.drawable.shop,R.drawable.cloths,
            R.drawable.game,R.drawable.packet,R.drawable.water,R.drawable.wine,R.drawable.fruit,R.drawable.riyong};
    private String[] textType = new String[]{"吃喝","交通","购物","服饰","娱乐","红包","水电","烟酒","水果","日用"};
    public int item_flag=1;//fragment第一次加载时默认选中的第一个


    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        //根据路径得到Typeface
        View outputLayout = inflater.inflate(R.layout.output_fragment, container, false);
        type_text = (TextView)getActivity().findViewById(R.id.textType);
        button1 = (Button)outputLayout.findViewById(R.id.it_icon1);
        button2 = (Button) outputLayout.findViewById(R.id.it_icon2);
        button3 = (Button) outputLayout.findViewById(R.id.it_icon3);
        button4 = (Button) outputLayout.findViewById(R.id.it_icon4);
        button5 = (Button) outputLayout.findViewById(R.id.it_icon5);
        button6 = (Button) outputLayout.findViewById(R.id.it_icon6);
        button7 = (Button) outputLayout.findViewById(R.id.it_icon7);
        button8 = (Button) outputLayout.findViewById(R.id.it_icon8);
        button9 = (Button) outputLayout.findViewById(R.id.it_icon9);
        button10 = (Button) outputLayout.findViewById(R.id.it_icon10);
        button1.setEnabled(false);//默认第一次启动第一个按钮
        icon_animation = AnimationUtils.loadAnimation(getContext(), R.anim.icon_zoom_out);
        initButtons();
        sendMessage(1);
        return outputLayout;
    }
    private  void initButtons(){
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);
        button9.setOnClickListener(this);
        button10.setOnClickListener(this);
        AccountActivity activity = (AccountActivity) getActivity();
        icon= (Button)activity.findViewById(R.id.icon);
        icon.setEnabled(false);

    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.it_icon1:
                item_flag = 1;
                sendMessage(item_flag);
                button1.setEnabled(false);
                button2.setEnabled(true);
                button3.setEnabled(true);
                button4.setEnabled(true);
                button5.setEnabled(true);
                button6.setEnabled(true);
                button7.setEnabled(true);
                button8.setEnabled(true);
                button9.setEnabled(true);
                button10.setEnabled(true);

                break;
            case R.id.it_icon2:
                item_flag = 2;
                sendMessage(item_flag);
                button1.setEnabled(true);
                button2.setEnabled(false);
                button3.setEnabled(true);
                button4.setEnabled(true);
                button5.setEnabled(true);
                button6.setEnabled(true);
                button7.setEnabled(true);
                button8.setEnabled(true);
                button9.setEnabled(true);
                button10.setEnabled(true);
                break;
            case R.id.it_icon3:
                item_flag = 3;
                sendMessage(item_flag);
                button1.setEnabled(true);
                button2.setEnabled(true);
                button3.setEnabled(false);
                button4.setEnabled(true);
                button5.setEnabled(true);
                button6.setEnabled(true);
                button7.setEnabled(true);
                button8.setEnabled(true);
                button9.setEnabled(true);
                button10.setEnabled(true);
                break;
            case R.id.it_icon4:
                item_flag = 4;
                sendMessage(item_flag);
                button1.setEnabled(true);
                button2.setEnabled(true);
                button3.setEnabled(true);
                button4.setEnabled(false);
                button5.setEnabled(true);
                button6.setEnabled(true);
                button7.setEnabled(true);
                button8.setEnabled(true);
                button9.setEnabled(true);
                button10.setEnabled(true);
                break;
            case R.id.it_icon5:
                item_flag = 5;
                sendMessage(item_flag);
                button1.setEnabled(true);
                button2.setEnabled(true);
                button3.setEnabled(true);
                button4.setEnabled(true);
                button5.setEnabled(false);
                button6.setEnabled(true);
                button7.setEnabled(true);
                button8.setEnabled(true);
                button9.setEnabled(true);
                button10.setEnabled(true);
                break;
            case R.id.it_icon6:
                item_flag = 6;
                sendMessage(item_flag);
                button1.setEnabled(true);
                button2.setEnabled(true);
                button3.setEnabled(true);
                button4.setEnabled(true);
                button5.setEnabled(true);
                button6.setEnabled(false);
                button7.setEnabled(true);
                button8.setEnabled(true);
                button9.setEnabled(true);
                button10.setEnabled(true);
                break;
            case R.id.it_icon7:
                item_flag = 7;
                sendMessage(item_flag);
                button1.setEnabled(true);
                button2.setEnabled(true);
                button3.setEnabled(true);
                button4.setEnabled(true);
                button5.setEnabled(true);
                button6.setEnabled(true);
                button7.setEnabled(false);
                button8.setEnabled(true);
                button9.setEnabled(true);
                button10.setEnabled(true);
                break;
            case R.id.it_icon8:
                item_flag = 8;
                sendMessage(item_flag);
                button1.setEnabled(true);
                button2.setEnabled(true);
                button3.setEnabled(true);
                button4.setEnabled(true);
                button5.setEnabled(true);
                button6.setEnabled(true);
                button7.setEnabled(true);
                button8.setEnabled(false);
                button9.setEnabled(true);
                button10.setEnabled(true);
                break;
            case R.id.it_icon9:
                item_flag = 9;
                sendMessage(item_flag);
                button1.setEnabled(true);
                button2.setEnabled(true);
                button3.setEnabled(true);
                button4.setEnabled(true);
                button5.setEnabled(true);
                button6.setEnabled(true);
                button7.setEnabled(true);
                button8.setEnabled(true);
                button9.setEnabled(false);
                button10.setEnabled(true);
                break;
            case R.id.it_icon10:
                item_flag = 10;
                sendMessage(item_flag);
                button1.setEnabled(true);
                button2.setEnabled(true);
                button3.setEnabled(true);
                button4.setEnabled(true);
                button5.setEnabled(true);
                button6.setEnabled(true);
                button7.setEnabled(true);
                button8.setEnabled(true);
                button9.setEnabled(true);
                button10.setEnabled(false);
                break;
            default:
                break;
        }
    }
    public void onResume(){
        button1.setEnabled(false);
        button2.setEnabled(true);
        button3.setEnabled(true);
        button4.setEnabled(true);
        button5.setEnabled(true);
        button6.setEnabled(true);
        button7.setEnabled(true);
        button8.setEnabled(true);
        button9.setEnabled(true);
        button10.setEnabled(true);
        item_flag=1;
        sendMessage(1);
        super.onResume();
    }

    private void sendMessage(int id){
        int pos = id -1;
        Drawable Icon = getResources().getDrawable(Icons[pos]);
        Icon.setBounds(0, 0, Icon.getMinimumWidth(),Icon.getMinimumHeight());
        icon.setCompoundDrawables(null, Icon,null,null);
        icon.setBackgroundResource(IconsBG[pos]);
        icon.startAnimation(icon_animation);
        type_text.setText(textType[pos]);
    }
}