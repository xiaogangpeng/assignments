package com.example.egbert.daliy.MVC;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.text.TextWatcher;
import android.util.Log;
import java.lang.reflect.Method;
import java.util.List;
import android.widget.Toast;

import com.example.egbert.daliy.MVC.View.KeyboardView;
import com.example.egbert.daliy.MVC.service.DatabaseHelper;
import com.example.egbert.daliy.R;
import com.example.egbert.daliy.MVC.Adapter.KeyboardAdapter;
import com.example.egbert.daliy.MVC.Controller.fragment.output_fragment;
import com.example.egbert.daliy.MVC.Controller.fragment.input_fragment;
import java.util.Calendar;

import android.app.DatePickerDialog.OnDateSetListener;

import java.text.SimpleDateFormat;
import java.util.Date;


public class AccountActivity extends AppCompatActivity implements KeyboardAdapter.OnKeyboardClickListener,View.OnClickListener {
    private Button input_Btn;
    private Button output_Btn;
    private TextView cancel_Btn;
    private TextView save_Btn;
    private EditText etInput;
    KeyboardView keyboardView;
    private List<String> datas;
    private input_fragment input_fragment;
    private output_fragment output_fragment;
    private FragmentManager fragmentManager;
    private String Date;  //用户选择的日期
    private TextView tvShowDialog;  //日期显示
    private Calendar cal;
    private int year,month,day;
    private DatabaseHelper helper;//数据库连接
    private String user_id = null;
    private Boolean user_statue = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        fragmentManager = getSupportFragmentManager();
        etInput = (EditText) findViewById(R.id.et_input);
        keyboardView = findViewById(R.id.keyboard_view);
        input_Btn = (Button) findViewById(R.id.input_button);
        output_Btn = (Button) findViewById(R.id.output_button);
        cancel_Btn = (TextView) findViewById(R.id.cancel_btn);
        save_Btn = (TextView) findViewById(R.id.save_btn);
        helper = new DatabaseHelper(this);

        SharedPreferences sharedPreferences = getSharedPreferences("user", Context.MODE_PRIVATE);
        user_id = sharedPreferences.getString("user_id", "null");
        user_statue = sharedPreferences.getBoolean("user_statue",false);

        // 设置不调用系统键盘
        if (Build.VERSION.SDK_INT <= 10) {
            etInput.setInputType(InputType.TYPE_NULL);
        } else {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            try {
                Class<EditText> cls = EditText.class;
                Method setShowSoftInputOnFocus = cls.getMethod("setShowSoftInputOnFocus", boolean.class);
                setShowSoftInputOnFocus.setAccessible(true);
                setShowSoftInputOnFocus.invoke(etInput, false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        etInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!keyboardView.isVisible()) {
                    keyboardView.show();
                }
            }
        });

        keyboardView.show();
        datas = keyboardView.getDatas();
        keyboardView.setOnKeyBoardClickListener(this);



        //收入支出按钮切换
        output_Btn.setActivated(true);
        setTabSelection(0);;//默认活动一开始是支出选项卡激活状态
        input_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                output_Btn.setActivated(false);
                input_Btn.setActivated(true);
                setTabSelection(1);
            }
        });
        output_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                output_Btn.setActivated(true);
                input_Btn.setActivated(false);
                setTabSelection(0);
            }
        });



        getDate();

        tvShowDialog=(TextView) findViewById(R.id.tvShowDialog);
        tvShowDialog.setOnClickListener(this);

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");// HH:mm:ss//获取当前时间
        Date date = new Date(System.currentTimeMillis());
        Date = simpleDateFormat.format(date);
        tvShowDialog.setText(Date);



        cancel_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                overridePendingTransition(0, R.anim.push_down_out);
            }
        });
        save_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user_statue==true) {    //判断是否登录  如果登录了执行数据库保存
                    if(etInput.getText().toString().equals("0.00")) {
                        Toast.makeText(AccountActivity.this,"请输入金额",Toast.LENGTH_LONG).show();
                    }
                    else {
                        if (output_Btn.isActivated() == true) {
                            SQLiteDatabase db = helper.getWritableDatabase();
                            ContentValues mycv = new ContentValues();
                            mycv.put("mobileNum", user_id);
                            mycv.put("type", output_fragment.item_flag);
                            mycv.put("value", etInput.getText().toString());
                            mycv.put("date", Date);
                            long id = db.insert("output", null, mycv);
                            if (id != -1) {

                                Toast.makeText(AccountActivity.this, "保存成功", Toast.LENGTH_LONG).show();
                                db.close();
                            } else {
                                Toast.makeText(AccountActivity.this, "保存失败", Toast.LENGTH_LONG).show();
                                db.close();
                            }
                        }
                        if (input_Btn.isActivated() == true) {
                            SQLiteDatabase db = helper.getWritableDatabase();
                            ContentValues mycv = new ContentValues();
                            mycv.put("mobileNum", user_id);
                            mycv.put("type", input_fragment.item_flag);
                            mycv.put("value", etInput.getText().toString());
                            mycv.put("date", Date);
                            long id = db.insert("input", null, mycv);
                        }
                        finish();
                        overridePendingTransition(0, R.anim.push_down_out);
                    }
                }
                else {
                    Toast.makeText(AccountActivity.this,"请先登录",Toast.LENGTH_LONG).show();
                }
            }
        });


        inputMoney();//金钱输入框监听操作函数

    }


    @Override
    public void onKeyClick(View view, RecyclerView.ViewHolder holder, int position) {
        switch (position) {
            case 9: // 按下小数点
                keyboardView.dismiss();
                break;
            default: // 按下数字键
                if ("0".equals(etInput.getText().toString().trim())) { // 第一个数字按下0的话，第二个数字只能按小数点
                    break;
                }
                etInput.setText(etInput.getText().toString().trim() + datas.get(position));
                etInput.setSelection(etInput.getText().length());
                break;
        }
    }

    @Override
    public void onDeleteClick(View view, RecyclerView.ViewHolder holder, int position) {
        // 点击删除按钮
        String num = etInput.getText().toString().trim();
        if (num.length() > 0) {
            etInput.setText(num.substring(0, num.length() - 1));
            etInput.setSelection(etInput.getText().length());
        }
    }

    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(0, R.anim.push_down_out);
        super.onBackPressed();
    }



    public void inputMoney(){
        etInput.requestFocus();
        etInput.addTextChangedListener(new TextWatcher() {
            String numberStr;//定义一个字符串来得到处理后的金额
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (TextUtils.isEmpty(getAmount())){//如果金额为空，重新设置金额，光标移到最后
                    numberStr = "0.00";
                    setAmount(numberStr);
                    moveCursorEnd(numberStr.length());
                }
                if (isChanged()){//如果金额发生改变，格式化金额
                    numberStr = getMoneyStr(s.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                String _etStr = getAmount();
                //UtilLogs.e(_etStr + "====" + numberStr);
                //判断输入框的值是否等于金额的值，如果不相同则赋值，如果不断判断TextWatch将会死循环
                if (isChanged()) {//重要：如果文字沒有改变，不再为EditText重新赋值
                    setAmount(numberStr);//为EditText赋值
                    moveCursorEnd(numberStr.length());//将光标定位到结尾
                }
            }
            private boolean isChanged(){
                String _etStr = getAmount();
                return !TextUtils.isEmpty(getAmount()) && !_etStr.equals(numberStr);
            }

            /*获得金额，此方法做了格式化金额操作，移动小数点，删0，补0*/
            private String getMoneyStr(String pMoney){
                //定义一个StringBuilder，便于操作字符串
                StringBuilder _moneyBuf = new StringBuilder(pMoney);

                //①删除小数点（如果有）
                int _dotIndex = _moneyBuf.indexOf(".");
                if (!(_dotIndex < 0)) {
                    _moneyBuf.deleteCharAt(_dotIndex);
                }

                //②判断字符串长度，>3,第一个字符为"0"，删除掉；<3,前面补0，保持至少三位数
                int _len = _moneyBuf.length();
                if (_len > 3 && "0".equals(_moneyBuf.substring(0, 1))) {
                    _moneyBuf.deleteCharAt(0);
                } else {
                    for (int i = 0; i < 3 - _len; i++) {
                        _moneyBuf.insert(0, "0");
                    }
                }
                //③将小数点插入倒数第二位和第三位之间，保证两位小数
                _moneyBuf.insert(_moneyBuf.length() - 2, ".");

                return _moneyBuf.toString();
            }
        });
    }



    /*获得输入框中的金额*/
    private String getAmount(){
        return etInput.getText().toString();
    }

    /*输入框设置金额*/
    private void setAmount(String pAmount){
       etInput.setText(pAmount);
    }

    /*将光标移到最后*/
    private void moveCursorEnd(int pEnd){
        etInput.setSelection(pEnd);
    }




    private void hideFragments(FragmentTransaction transaction) {
        if (output_fragment != null) {
            transaction.hide(output_fragment);
        }
        if(input_fragment != null) {
            transaction.hide(input_fragment);
        }
    }


    private void setTabSelection(int index) {
        // 每次选中之前先清楚掉上次的选中状态
        // 开启一个Fragment事务
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        // 先隐藏掉所有的Fragment，以防止有多个Fragment显示在界面上的情况
        hideFragments(transaction);
        switch (index) {
            case 0:
                if(input_fragment!=null)
                    transaction.hide(input_fragment);
                if (output_fragment == null) {
                    // 如果支出Fragment为空，则创建一个并添加到界面上
                    output_fragment = new output_fragment();
                    transaction.add(R.id.fl_container, output_fragment);
                } else {
                    // 如果支出Fragment不为空，则直接将它显示出来
                    output_fragment.onResume();
                    transaction.show(output_fragment);

                }

                break;
            case 1:
                if(output_fragment!=null)
                    transaction.hide(output_fragment);
                if (input_fragment == null) {
                    // 如果ContactsFragment为空，则创建一个并添加到界面上
                    input_fragment = new input_fragment();
                    transaction.add(R.id.fl_container, input_fragment);
                } else {
                    // 如果ContactsFragment不为空，则直接将它显示出来
                    input_fragment.onResume();
                    transaction.show(input_fragment);
                }
                //如果第一个碎片不为空就将其移除，以便下次重新加载
                break;

            default:
                break;
        }
        transaction.commit();
    }


    private void getDate() {
        cal=Calendar.getInstance();
        year=cal.get(Calendar.YEAR);       //获取年月日时分秒
        Log.i("wxy","year"+year);
        month=cal.get(Calendar.MONTH);   //获取到的月份是从0开始计数
        day=cal.get(Calendar.DAY_OF_MONTH);
    }


    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tvShowDialog:
                OnDateSetListener listener=new OnDateSetListener() {
                    public void onDateSet(DatePicker arg0, int year, int month, int day) {
                        if(day<10)
                            Date = year+"-"+(++month)+"-"+"0"+day;
                        else
                            Date = year+"-"+(++month)+"-"+day;
                        tvShowDialog.setText(Date);      //将选择的日期显示到TextView中,因为之前获取month直接使用，所以不需要+1，这个地方需要显示，所以+1
                        keyboardView.show();
                    }
                };
                DatePickerDialog dialog=new DatePickerDialog(AccountActivity.this, 0,listener,year,month,day);//后边三个参数为显示dialog时默认的日期，月份从0开始，0-11对应1-12个月
                keyboardView.dismiss();
                dialog.show();
                break;

            default:
                break;
        }
    }





}

