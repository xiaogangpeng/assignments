package com.example.egbert.daliy.MVC.Controller.fragment;

import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.egbert.daliy.R;


public class GuildFragment extends Fragment {
    private View guildFragment;
    private ImageView customView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        guildFragment = inflater.inflate(R.layout.fm_guild, container, false);
        customView = (ImageView) guildFragment.findViewById(R.id.cv);
        /**获取参数，根据不同的参数播放不同的视频**/
        int index = getArguments().getInt("index");
        Drawable drawable;
        if (index == 1) {
            drawable = getResources().getDrawable(R.drawable.guild1);
        } else if (index == 2) {
            drawable = getResources().getDrawable(R.drawable.guild2);
        } else {
            drawable = getResources().getDrawable(R.drawable.guild3);
        }
        customView.setImageDrawable(drawable);
        return guildFragment;
    }


}
