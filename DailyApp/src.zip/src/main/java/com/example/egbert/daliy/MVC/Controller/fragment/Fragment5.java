package com.example.egbert.daliy.MVC.Controller.fragment;

/**
 * Created by ScottPong on 2018/11/12.
 */

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.egbert.daliy.MVC.LoginActivity;
import com.example.egbert.daliy.MVC.MessageActivity;
import com.example.egbert.daliy.MVC.SettingActivity;
import com.example.egbert.daliy.MVC.service.DatabaseHelper;
import com.example.egbert.daliy.R;
import com.example.egbert.daliy.MVC.View.CircleImageView;

import java.util.Calendar;


public class Fragment5 extends Fragment {
    private Thread mThread;
    private Handler handler;
    private View Fragment5_Layout;
    private DatabaseHelper helper;
    private String nickName;
    private String user_id = null;
    private Boolean user_statue = false;
    private TextView nickNameView;//用户名信息
    private TextView countDetail;
    private TextView countDay;
    private TextView item8;
    private  CircleImageView head_btn;//头像按钮

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences sharedPreferences = getContext().getSharedPreferences("user", Context.MODE_PRIVATE);
        user_id = sharedPreferences.getString("user_id", "null");
        user_statue = sharedPreferences.getBoolean("user_statue",false);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Fragment5_Layout = inflater.inflate(R.layout.fragment5, container, false);
        findViews();
        return Fragment5_Layout;
    }


    private void getUserData(final String id){
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 0:
                        nickNameView.setText((CharSequence) msg.obj);
                    case 1:
                        countDay.setText((CharSequence) msg.obj);
                    case 2:
                       countDetail.setText((CharSequence) msg.obj);
                }
            }
        };

        mThread = new Thread(new Runnable() {

            @Override
            public void run() {

                    int countDetail;
                    int countDay = 0;
                    String currentDay;
                    helper = new DatabaseHelper(getContext());
                    SQLiteDatabase db = helper.getWritableDatabase();
                    Cursor cursor1 = db.query("admin", null, "mobileNum=?", new String[]{id}, null, null, null);
                    while (cursor1.moveToNext()) {
                        nickName = cursor1.getString(cursor1.getColumnIndex("userName"));  //获取用户名
                    }
                    Cursor cursor2 = db.query("output", null, "mobileNum=?", new String[]{id}, null, null, "date"+" DESC");
                    Cursor cursor3 = db.query("input", null, "mobileNum=?", new String[]{id}, null, null, "date"+" DESC");
                    countDetail = cursor2.getCount() + cursor3.getCount();
                    while (cursor2.moveToNext()) {
                        currentDay = cursor2.getString(cursor2.getColumnIndex("date"));
                        if(currentDay!=cursor2.getString(cursor2.getColumnIndex("date"))){
                            countDay++;
                            currentDay = cursor2.getString(cursor2.getColumnIndex("date"));
                        }
                    }

                for(int i =0 ;i<3;i++) {
                    Message message = new Message();
                    switch (i){
                        case 0 :message.obj = nickName;
                            message.what = 0;
                            break;
                        case 1:message.obj = ""+countDay;
                            message.what = 1;
                            break;
                        case 2:message.obj = ""+countDetail;
                            message.what = 2;
                            break;
                        default:break;
                    }
                    handler.sendMessage(message);
                }
                db.close();
            }
        });
        mThread.start();

    }

    private void findViews(){
        nickNameView = (TextView)Fragment5_Layout.findViewById(R.id.nick_name);
        head_btn= (CircleImageView) Fragment5_Layout.findViewById(R.id.head_btn);
        countDay =  (TextView)Fragment5_Layout.findViewById(R.id.count_day);
        countDetail=  (TextView)Fragment5_Layout.findViewById(R.id.count_detail);
        item8 = (TextView)Fragment5_Layout.findViewById(R.id.item8);
        item8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), MessageActivity.class);
                startActivity(intent);
            }
        });
        if(user_statue==true){
            head_btn.setImageResource(R.drawable.head_default);
            getUserData(user_id);
            head_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getContext(), SettingActivity.class);
                    startActivity(intent);
                }
            });
        }
        else {
            head_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getContext(), LoginActivity.class);
                    startActivity(intent);
                }
            });
        }

    }


    public void onResume(){
        getUserData(user_id);
        super.onResume();
    }

}