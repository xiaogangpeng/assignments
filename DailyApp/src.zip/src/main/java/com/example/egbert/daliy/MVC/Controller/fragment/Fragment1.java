package com.example.egbert.daliy.MVC.Controller.fragment;


import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.egbert.daliy.MVC.LoginActivity;
import com.example.egbert.daliy.MVC.View.CircleImageView;
import com.example.egbert.daliy.MVC.utils.ScreenUtils;
import com.example.egbert.daliy.MVC.service.DatabaseHelper;
import com.example.egbert.daliy.MVC.widget.SlidingDeleteView;
import com.example.egbert.daliy.R;
import java.util.ArrayList;
import java.util.List;
import android.content.Intent;


public class Fragment1 extends Fragment {
    private Thread mThread;
    private Handler handler;
    private String user_id = null;
    private boolean user_statue = false;
    private DatabaseHelper helper;
    private int[] input_id;
    private int[] inputColors;
    private String[] inputType;
    private int[] inputIcons;
    private String[] inputDates;
    private String[] inputValues;
    private int[] output_id;
    private String[] outputType;
    private int[] outputColors;
    private int[] outputIcons;
    private String[] outputDates;
    private String[] outputValues;
    private List<String> listDate = new ArrayList<String>();//账单消费日期
    private List<Integer> listIcon = new ArrayList<Integer>();//账单消费类型图标容器
    private List<String> listName = new ArrayList<String>();// 账单消费类型容器
    private List<String> listValue = new ArrayList<String>(); //账单消费金额容器
    private List<Integer> listColor = new ArrayList<Integer>();//icon背景颜色容器
    private List<Integer> listID = new ArrayList<Integer>();//信息id容器
    private LinearLayout output_btn;
    private LinearLayout input_btn;
    private Button goto_login; //前往登陆界面按钮
    private int itemCount;//内容数量
    private View Fragment1_Layout;
    private View Fragment1_unlog;
    private TextView billSum;
    private TextView outputSum;
    private TextView inputSum;
    RecyclerView recyclerView;
    MyAdapter myAdapter;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences sharedPreferences = getContext().getSharedPreferences("user", Context.MODE_PRIVATE);
        user_id = sharedPreferences.getString("user_id", "null");
        user_statue = sharedPreferences.getBoolean("user_statue",false);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Fragment1_Layout = inflater.inflate(R.layout.fragment1, container, false);
        Fragment1_unlog = inflater.inflate(R.layout.fragment1_1,container,false);
        recyclerView = (RecyclerView)Fragment1_Layout.findViewById(R.id.recyclerview);
        output_btn = (LinearLayout) Fragment1_Layout.findViewById(R.id.output_btn);
        input_btn = (LinearLayout) Fragment1_Layout.findViewById(R.id.input_btn);
        billSum = (TextView) Fragment1_Layout.findViewById(R.id.billSum);
        outputSum = (TextView) Fragment1_Layout.findViewById(R.id.outputSum);
        inputSum = (TextView) Fragment1_Layout.findViewById(R.id.inputSum);
        goto_login = (Button) Fragment1_unlog.findViewById(R.id.goto_login);
        goto_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(),LoginActivity.class);
                startActivity(intent);
                getActivity().finish();
            }
        });
        output_btn.setActivated(true);//默认第一次显示支出列表  支出按钮激活
        input_btn.setActivated(false);
        data();//第一次加载数据库
        getData(user_id);
        modeChange();
        myAdapter = new MyAdapter();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.addItemDecoration(new DividerItemDecoration(getContext(), LinearLayout.VERTICAL));
        recyclerView.setAdapter(myAdapter);
        if(user_statue==true){
            return Fragment1_Layout;
        }
        else{
            return Fragment1_unlog;  //进入主界面判断登陆状态，未登录加载未登录界面
        }
    }

    public void onResume(){
        data();
        getData(user_id);
        super.onResume();
    }




    class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(getContext()).inflate(R.layout.sample_slidingview, parent, false);
            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final MyViewHolder holder, final int position) {
            //TODO 这里需要重新计算 item - containerView的宽度，否则containerView会显示错误(重要)
            RelativeLayout containerView = (RelativeLayout) holder.slidingDeleteView.findViewById(R.id.lay_container);
            containerView.getLayoutParams().width = ScreenUtils.getScreenWidth(getContext());
            holder.slidingDeleteView.setEnable(true);
            holder.slidingDeleteView.setOnDeleteViewStateChangedListener(new SlidingDeleteView.OnDeleteViewStateChangedListener() {
                @Override
                public void onVisibile() {

                }

                @Override
                public void onGone() {

                }

                @Override
                public void onDownOrMove() {

                }
            });

            Drawable drawable=getResources().getDrawable(listIcon.get(position));
            drawable.setBounds(0,0,50,50);//第一0是距左边距离，第二0是距上边距离，30、35分别是长宽
            holder.tvKey.setCompoundDrawables(drawable,null,null,null);//只放左边
            holder.tvKey.setEnabled(false);
            holder.tvKey.setBackgroundResource(listColor.get(position));
            holder.tvType.setText(listName.get(position));
            holder.tvValue.setText(listValue.get(position));
            holder.tvDate.setText(listDate.get(position));
            holder.tvDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    helper = new DatabaseHelper(getContext());
                    SQLiteDatabase db = helper.getWritableDatabase();
                    int id = listID.get(position);
                    if(output_btn.isActivated()==true){
                        db.delete("output","_id = ?", new String[]{Integer.toString(id)});
                    }
                    else {
                        db.delete("input", "_id = ?", new String[]{Integer.toString(id)});
                    }
                    db.close();
                    data();
                    getData(user_id);
                    myAdapter.notifyItemRemoved(position);
                }
            });
        }

        @Override
        public int getItemCount() {
            return itemCount;
        }


    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        SlidingDeleteView slidingDeleteView;
        Button tvKey;
        TextView tvType;
        TextView tvDelete;
        TextView tvDate;
        TextView tvValue;

        public MyViewHolder(View itemView) {
            super(itemView);
            slidingDeleteView = (SlidingDeleteView) itemView.findViewById(R.id.slidingview);
            tvKey = (Button) itemView.findViewById(R.id.tv_key);
            tvType = (TextView) itemView.findViewById(R.id.tv_type);
            tvDelete = (TextView) itemView.findViewById(R.id.tv_delete);
            tvDate = (TextView) itemView.findViewById(R.id.tv_date);
            tvValue = (TextView) itemView.findViewById(R.id.tv_value);
        }

    }


    private void data(){  //刷新一遍数据库信息
        listName.clear();
        listIcon.clear();
        listDate.clear();
        listValue.clear();
        listColor.clear();
        helper = new DatabaseHelper(getContext());
        SQLiteDatabase db = helper.getWritableDatabase();
        Cursor cursor1 = db.query("output", null, "mobileNum=?", new String[]{user_id}, null, null, "date"+" DESC");
        outputType = new String [cursor1.getCount()];
        outputIcons = new int[cursor1.getCount()];
        outputDates = new String[cursor1.getCount()];
        outputValues = new String[cursor1.getCount()];
        outputColors = new int[cursor1.getCount()];
        output_id = new int[cursor1.getCount()];
        int i = 0;
        while (cursor1.moveToNext()) {
            switch (cursor1.getString(cursor1.getColumnIndex("type"))){
                case "0":break;
                case "1":outputType[i] = "吃喝";outputIcons[i]= R.drawable.food;outputColors[i]=R.drawable.item_icon1;break;
                case "2":outputType[i] = "交通";outputIcons[i]= R.drawable.trans;outputColors[i]=R.drawable.item_icon2;break;
                case "3":outputType[i] = "购物";outputIcons[i]= R.drawable.shop;outputColors[i]=R.drawable.item_icon3;break;
                case "4":outputType[i] = "服饰";outputIcons[i]= R.drawable.cloths;outputColors[i]=R.drawable.item_icon4;break;
                case "5":outputType[i] = "娱乐";outputIcons[i]= R.drawable.game;outputColors[i]=R.drawable.item_icon5;break;
                case "6":outputType[i] = "红包";outputIcons[i]= R.drawable.packet;outputColors[i]=R.drawable.item_icon6;break;
                case "7":outputType[i] = "水电";outputIcons[i]= R.drawable.water;outputColors[i]=R.drawable.item_icon7;break;
                case "8":outputType[i] = "烟酒";outputIcons[i]= R.drawable.wine;outputColors[i]=R.drawable.item_icon8;break;
                case "9":outputType[i] = "水果";outputIcons[i]= R.drawable.fruit;outputColors[i]=R.drawable.item_icon9;break;
                case "10":outputType[i] ="日用";outputIcons[i]= R.drawable.riyong;outputColors[i]=R.drawable.item_icon10;break;
                default:break;

            }
            outputDates[i] = cursor1.getString(cursor1.getColumnIndex("date"));
            outputValues[i] = "-"+cursor1.getString(cursor1.getColumnIndex("value"));
            output_id[i] = cursor1.getInt(cursor1.getColumnIndex("_id"));
            i++;
        }

        Cursor cursor2 = db.query("input", null, "mobileNum=?", new String[]{user_id}, null, null, "date"+" DESC");
        inputType = new String [cursor2.getCount()];
        inputIcons = new int[cursor2.getCount()];
        inputDates = new String[cursor2.getCount()];
        inputValues = new String[cursor2.getCount()];
        inputColors = new int[cursor2.getCount()];
        input_id = new int[cursor2.getCount()];
        int j = 0;
        while (cursor2.moveToNext()) {
            switch (cursor2.getString(cursor2.getColumnIndex("type"))){
                case "0":break;
                case "1":inputType[j] = "工资";inputIcons[j]= R.drawable.card;inputColors[j]=R.drawable.item_icon1;break;
                case "2":inputType[j] = "红包";inputIcons[j]= R.drawable.redpacket;inputColors[j]=R.drawable.item_icon2;break;
                case "3":inputType[j] = "奖金";inputIcons[j]= R.drawable.scollarship;inputColors[j]=R.drawable.item_icon3;break;
                case "4":inputType[j] = "理财";inputIcons[j]= R.drawable.bussiness;inputColors[j]=R.drawable.item_icon4;break;
                case "5":inputType[j] = "兼职";inputIcons[j]= R.drawable.job;inputColors[j]=R.drawable.item_icon5;break;
                case "6":inputType[j] = "补助";inputIcons[j]= R.drawable.help;inputColors[j]=R.drawable.item_icon6;break;
                case "7":inputType[j] = "报销";inputIcons[j]= R.drawable.bill;inputColors[j]=R.drawable.item_icon7;break;
                case "8":inputType[j] = "退款";inputIcons[j]= R.drawable.backward;inputColors[j]=R.drawable.item_icon8;break;
                default:break;
            }
            inputDates[j] = cursor2.getString(cursor2.getColumnIndex("date"));
            inputValues[j] = cursor2.getString(cursor2.getColumnIndex("value"));
            input_id[j] = cursor2.getInt(cursor2.getColumnIndex("_id"));
            j++;
        }

        if(output_btn.isActivated()==true){
            listID.clear();//先把id容器清空
            itemCount = cursor1.getCount();
            db.close();
            for (i=0;i<itemCount;i++){
                listName.add(outputType[i]);
                listIcon.add(outputIcons[i]);
                listDate.add(outputDates[i]);
                listValue.add(outputValues[i]);
                listColor.add(outputColors[i]);
                listID.add(output_id[i]);
            }
        }


        if(input_btn.isActivated()==true){
            listID.clear();//先把id容器清空
            itemCount = cursor2.getCount();
            db.close();
            for (i=0;i<itemCount;i++){
                listName.add(inputType[i]);
                listIcon.add(inputIcons[i]);
                listDate.add(inputDates[i]);
                listValue.add(inputValues[i]);
                listColor.add(inputColors[i]);
                listID.add(input_id[i]);
            }
        }

    }

    private void modeChange(){
        output_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                output_btn.setActivated(true);
                input_btn.setActivated(false);
                data();
                recyclerView.setAdapter(myAdapter);
            }
        });
        input_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                output_btn.setActivated(false);
                input_btn.setActivated(true);
                data();
                recyclerView.setAdapter(myAdapter);
            }
        });
    }


    public Drawable zoomImage(int resId, int w, int h){
        Resources res = getResources();
        Bitmap oldBmp = BitmapFactory.decodeResource(res, resId);
        Bitmap newBmp = Bitmap.createScaledBitmap(oldBmp,w, h, true);
        Drawable drawable = new BitmapDrawable(res, newBmp);
        return drawable;
    }



    private void getData(final String id){    //获取账单收入支出综合信息
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 0:
                        billSum.setText((CharSequence) msg.obj);
                    case 1:
                        outputSum.setText((CharSequence) msg.obj);
                    case 2:
                        inputSum.setText((CharSequence) msg.obj);
                }
            }
        };
        mThread = new Thread(new Runnable() {

            @Override
            public void run() {

                float sum = 0;
                float output_sum = 0;
                float input_sum = 0;
                helper = new DatabaseHelper(getContext());
                SQLiteDatabase db = helper.getWritableDatabase();
                Cursor cursor1 = db.query("output", null, "mobileNum=?", new String[]{id}, null, null, "date"+" DESC");
                Cursor cursor2 = db.query("input", null, "mobileNum=?", new String[]{id}, null, null, "date"+" DESC");
                while (cursor1.moveToNext()) {
                    output_sum += Float.parseFloat(cursor1.getString(cursor1.getColumnIndex("value")));
                }
                while (cursor2.moveToNext()) {
                    input_sum += Float.parseFloat(cursor2.getString(cursor2.getColumnIndex("value")));
                }
                sum = input_sum - output_sum;
                for(int i =0 ;i<3;i++) {
                    Message message = new Message();
                    switch (i){
                        case 0 :message.obj = ""+sum;
                            message.what = 0;
                            break;
                        case 1:message.obj = ""+output_sum;
                            message.what = 1;
                            break;
                        case 2:message.obj = ""+input_sum;
                            message.what = 2;
                            break;
                        default:break;
                    }
                    handler.sendMessage(message);
                }
                db.close();
            }
        });
        mThread.start();
    }

}