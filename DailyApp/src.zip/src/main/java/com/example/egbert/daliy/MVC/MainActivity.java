package com.example.egbert.daliy.MVC;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.example.egbert.daliy.MVC.Controller.fragment.Fragment1;
import com.example.egbert.daliy.MVC.Controller.fragment.Fragment2;
import com.example.egbert.daliy.MVC.Controller.fragment.Fragment3;
import com.example.egbert.daliy.MVC.Controller.fragment.Fragment4;
import com.example.egbert.daliy.MVC.Controller.fragment.Fragment5;
import com.example.egbert.daliy.MVC.View.BottomBar;
import com.example.egbert.daliy.R;
import com.plattysoft.leonids.ParticleSystem;
import android.content.SharedPreferences;
import android.content.Context;

public class MainActivity extends AppCompatActivity {
    private Thread mThread;
    private MainActivity mActivity;
    private Button write_Btn;
    private String user_id = null;
    private Boolean user_statue = false;
    BottomBar bottomBar;
    private boolean firstLanuch =true;
    private boolean firstAnimation;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mActivity = this;
        sharedPreferences = getSharedPreferences("user", Context.MODE_PRIVATE);
        user_id = sharedPreferences.getString("user_id", "null");
        user_statue = sharedPreferences.getBoolean("user_statue",false);
        firstAnimation = sharedPreferences.getBoolean("firstLaunched",false);
        bottomBar = findViewById(R.id.bottom_bar);
        bottomBar.setContainer(R.id.fl_container)
                .setTitleBeforeAndAfterColor("#000000", "#00ba91")
                .addItem(Fragment1.class,
                        "账单",
                        R.drawable.zhangdan_before,
                        R.drawable.zhangdan_after)
                .addItem(Fragment2.class,
                        "图表",
                        R.drawable.tubiao_before,
                        R.drawable.tubiao_after)
                .addItem(Fragment3.class,
                        "记账",
                        R.drawable.bianjisekuai,
                        R.drawable.bianjisekuai)
                .addItem(Fragment4.class,
                        "发现",
                        R.drawable.faxian_before,
                        R.drawable.faxian_after)
                .addItem(Fragment5.class,
                        "我的",
                        R.drawable.wode_before,
                        R.drawable.wode_after)
                .build();


        write_Btn = (Button) findViewById(R.id.write_btn);
        write_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,AccountActivity.class );
                startActivity(intent);
                    // 参数1：MainActivity进场动画，参数2：SecondActivity出场动画
                overridePendingTransition(R.anim.push_down_in, 0);

            }
        });

        if(firstAnimation)

                    animation();
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    //如果不能找到Editor接口。尝试使用 SharedPreferences.Editor
                    editor.putBoolean("firstLaunched",false);//设置登录状态为真表示已登录
                    //我将用户信息保存到其中，你也可以保存登录状态
                    editor.commit();


    }

    public void onResume(){

        Log.e("MainActivity","onResume is running");
        //restartActivity(MainActivity.this);
        super.onResume();
        if(firstLanuch)
            firstLanuch = false;
        else
            restartActivity(MainActivity.this);
        firstLanuch = false;
    }

    @Override
    protected void onRestart() {
        Log.e("MainActivity","onRestart is running");
        super.onRestart();
        restartActivity(MainActivity.this);

    }

    public static void restartActivity(Activity activity){
        Intent intent = new Intent();
        intent.setClass(activity, activity.getClass());
        activity.startActivity(intent);
        activity.overridePendingTransition(0,0);
        activity.finish();
    }


    private void animation(){

        new ParticleSystem(mActivity, 10, R.mipmap.can1, 10000)
                        .setSpeedModuleAndAngleRange(0.05f, 0.2f, 0, 90)
                        .setRotationSpeed(10)
                        .setAcceleration(0.00005f, 90)
                        .emit(0, -100, 30, 10000);
        new ParticleSystem(mActivity, 10, R.mipmap.can2, 10000)
                .setSpeedModuleAndAngleRange(0.05f, 0.2f, 0, 90)
                .setRotationSpeed(20)
                .setAcceleration(0.00005f, 90)
                .emit(0, -100, 30, 10000);

        new ParticleSystem(mActivity, 10, R.mipmap.can3, 10000)
                .setSpeedModuleAndAngleRange(0.05f, 0.2f, 0, 90)
                .setRotationSpeed(30)
                .setAcceleration(0.00005f, 90)
                .emit(0, -100, 30, 10000);

        new ParticleSystem(mActivity, 10, R.mipmap.can4, 10000)
                .setSpeedModuleAndAngleRange(0.05f, 0.2f, 0, 90)
                .setRotationSpeed(40)
                .setAcceleration(0.00005f, 90)
                .emit(0, -100, 30, 10000);

        new ParticleSystem(mActivity, 10, R.mipmap.can5, 10000)
                .setSpeedModuleAndAngleRange(0.05f, 0.2f, 0, 90)
                .setRotationSpeed(50)
                .setAcceleration(0.00005f, 90)
                .emit(0, -100, 30, 10000);

        new ParticleSystem(mActivity, 10, R.mipmap.can6, 10000)
                .setSpeedModuleAndAngleRange(0.05f, 0.2f, 0, 90)
                .setRotationSpeed(60)
                .setAcceleration(0.00005f, 90)
                .emit(0, -100, 30, 10000);


    }


}

