package com.example.egbert.daliy.MVC.Model;

/**
 * Created by ScottPong on 2018/11/23.
 */

public class Food {

    private String mName;

    public Food(String name){
        mName = name;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }
}
